python3 sender.py $1 $2 $3 $4
