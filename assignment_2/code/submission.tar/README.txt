# Supreme Train 

## Build
Server & Client are python based, no compilation is required. 

## Usage
`server.sh` and `client.sh` scripts run both the server and client respectively. To run the server:

```
./server.sh  host_addr port_data port_acks file_name
```

To run the Client:
```
./client.sh host_addr port_ack port_data file_name
```


