python3 receiver.py $1 $2 $3 $4
