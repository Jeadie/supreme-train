#!/bin/bash

python code/peer.py $1 $2 $3