#!/bin/bash

python code/tracker.py