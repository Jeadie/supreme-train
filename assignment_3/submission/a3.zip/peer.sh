#!/bin/bash

python3 code/peer.py $1 $2 $3