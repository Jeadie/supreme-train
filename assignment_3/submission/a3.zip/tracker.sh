#!/bin/bash

python3 code/tracker.py